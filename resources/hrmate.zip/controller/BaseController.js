sap.ui.define(["sap/ui/core/mvc/BaseController","sap/m/MessageBox"],(e,r)=>{"use strict";return e.extend("hrmate.BaseController.login",{onInit(){}})});
//# sourceMappingURL=BaseController.js.map