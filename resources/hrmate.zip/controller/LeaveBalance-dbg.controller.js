sap.ui.define(["sap/ui/core/mvc/Controller","sap/m/MessageBox"], (Controller,MessageBox) => {
  "use strict";

  return Controller.extend("hrmate.controller.LeaveBalance", {
    onInit() {
      debugger;
    },
    onAfterRendering() {
      debugger;
        // var xValues = ["Italy", "France", "Spain", "USA", "Argentina"];
        // var yValues = [55, 49, 44, 24, 15];
        // var barColors = ["#b91d47", "#00aba9", "#2b5797", "#e8c3b9", "#1e7145"];
        // var ctx=this.getView().byId("card")

        // new Chart(ctx), {
        //   type: "doughnut",
        //   data: {
        //     labels: xValues,
        //     datasets: [
        //       {
        //         backgroundColor: barColors,
        //         data: yValues,
        //       },
        //     ],
        //   },
        //   options: {
        //     title: {
        //       display: true,
        //       text: "World Wide Wine Production 2018",
        //     },
        //   },
        // };
    //     var pieChartData = {
    //       type: "doughnut",
    //       labels: [
    //             "Red",
    //             "Blue",
    //             "Yellow"
    //         ],
    //         datasets: [{
    //               data: [300, 50, 100],
    //               backgroundColor: [
    //                   "#FF6384",
    //                   "#36A2EB",
    //                   "#FFCE56"
    //               ],
    //               hoverBackgroundColor: [
    //                   "#FF6384",
    //                   "#36A2EB",
    //                   "#FFCE56"
    //               ]
    //           }]
    //     };
    //     this.getView().setModel( new sap.ui.model.json.JSONModel({
 
    //       pieChart: pieChartData,
     
    //     }), "temp");
             
     }
    
  });
});
