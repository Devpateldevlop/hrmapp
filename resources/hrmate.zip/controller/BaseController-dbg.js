sap.ui.define(["sap/ui/core/mvc/BaseController","sap/m/MessageBox"], (BaseController,MessageBox) => {
    "use strict";
  
    return BaseController.extend("hrmate.BaseController.login", {
      onInit() {
       
      }
   
    
      
    });
  });
  